package com.shinjaehun.suksuk.presentation.common

enum class Highlight {
    None,
    Editing,
    Related
}