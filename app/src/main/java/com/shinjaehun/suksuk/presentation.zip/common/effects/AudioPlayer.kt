package com.shinjaehun.suksuk.presentation.common.effects

interface AudioPlayer {
    fun playBeep()
    fun playTada()
}