package com.shinjaehun.suksuk.presentation.multiplication

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.testTag
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.constraintlayout.compose.Dimension
import com.shinjaehun.suksuk.R
import com.shinjaehun.suksuk.domain.multiplication.model.MulCell
import com.shinjaehun.suksuk.domain.pattern.MulPattern
import com.shinjaehun.suksuk.presentation.multiplication.model.MulInputCell
import com.shinjaehun.suksuk.presentation.multiplication.model.MulUiState
import com.shinjaehun.suksuk.presentation.multiplication.model.TotalLineType


@Composable
fun MultiplicationBoard(
    uiState: MulUiState
) {
    val cellWidth = 42.dp
    val horizPadding = 8.dp
    val anchorStart = 100.dp   // 곱셈 기호의 시작 마진 (division의 브래킷 기준과 유사) 3x2에서는 60/80이 좋을 거 같음
    val gapAbove = 16.dp       // X 기준 위(피승수) 거리
    val gapBelow = 16.dp       // X 기준 아래(승수) 거리
    val lineTopMargin = 12.dp  // 승수 아래 첫 가로선까지 거리

    val colGap = cellWidth + horizPadding * 2  // 한 열(셀+패딩) 간격
    val row1 = 12.dp
    val row2 = 52.dp
    val rowSum = 100.dp

    ConstraintLayout(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 30.dp, vertical = 30.dp)
    ) {
        val (
            timesRef, mulLineRef, totalLineRef,
        ) = createRefs()

        val (
            mcHundredsRef, mcTensRef, mcOnesRef,
            mlTensRef, mlOnesRef
        ) = createRefs()

        val (
            p1TenThousandsRef, p1ThousandsRef, p1HundredsRef, p1TensRef, p1OnesRef,
            p2TenThousandsRef, p2ThousandsRef, p2HundredsRef, p2TensRef
        ) = createRefs()

        val (
            sumTenThousandsRef, sumThousandsRef, sumHundredsRef, sumTensRef, sumOnesRef
        ) = createRefs()

        val (
            carryP1HundredsRef, carryP1TensRef,
            carryP2HundredsRef, carryP2TensRef,
            carrySumTenThousandsRef, carrySumThousandsRef, carrySumHundredsRef
        ) = createRefs()

        Image(
            painter = painterResource(R.drawable.ic_multiply),
            contentDescription = "×",
            contentScale = ContentScale.Fit,
            modifier = Modifier.constrainAs(timesRef) {
                top.linkTo(parent.top, margin = 100.dp)
                start.linkTo(parent.start, margin = anchorStart)
                width = Dimension.value(35.dp)
                height = Dimension.value(35.dp)
            }
        )

        uiState.cells[MulCell.MultiplicandHundreds]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(mcHundredsRef) {
                        baseline.linkTo(mcTensRef.baseline)
                        end.linkTo(mcTensRef.start)
                    }
            )
        }

        uiState.cells[MulCell.CarryP1Hundreds]?.let { c ->
            MulAuxNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = 8.dp)
                    .constrainAs(carryP1HundredsRef) {
                        start.linkTo(mcHundredsRef.start)
                        bottom.linkTo(mcHundredsRef.top)
                    }
            )
        }

        uiState.cells[MulCell.CarryP2Hundreds]?.let { c ->
            MulAuxNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = 8.dp)
                    .constrainAs(carryP2HundredsRef) {
                        start.linkTo(mcHundredsRef.start)
                        bottom.linkTo(mcHundredsRef.top)
                    }
            )
        }

        uiState.cells[MulCell.MultiplicandTens]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(mcTensRef) {
                        bottom.linkTo(timesRef.top, margin = 15.dp)
                        start.linkTo(timesRef.end, margin = 40.dp)
                    }
            )
        }

        uiState.cells[MulCell.CarryP1Tens]?.let { c ->
            MulAuxNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = 8.dp)
                    .constrainAs(carryP1TensRef) {
                        start.linkTo(mcTensRef.start)
                        bottom.linkTo(mcTensRef.top)
                    }
            )
        }

        uiState.cells[MulCell.CarryP2Tens]?.let { c ->
            MulAuxNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = 8.dp)
                    .constrainAs(carryP2TensRef) {
                        start.linkTo(mcTensRef.start)
                        bottom.linkTo(mcTensRef.top)
                    }
            )
        }

        uiState.cells[MulCell.MultiplicandOnes]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(mcOnesRef) {
                        start.linkTo(mcTensRef.end)
                        baseline.linkTo(mcTensRef.baseline)
                    }
            )
        }

        uiState.cells[MulCell.MultiplierTens]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(mlTensRef) {
                        top.linkTo(mcTensRef.bottom, margin = 10.dp)
                        start.linkTo(mcTensRef.start)
                    }
            )
        }

        uiState.cells[MulCell.MultiplierOnes]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(mlOnesRef) {
                        start.linkTo(mlTensRef.end)
                        baseline.linkTo(mlTensRef.baseline)
                    }
            )
        }

        Image(
            painter = painterResource(id = R.drawable.ic_horizontal_line_long),
            contentDescription = "mul-line",
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .constrainAs(mulLineRef) {
                    top.linkTo(timesRef.bottom, margin = lineTopMargin)
                    start.linkTo(timesRef.start, margin = (-20).dp) 
                    width = Dimension.value(200.dp)
                    height = Dimension.value(4.dp)
                }
                .semantics { testTag = "mul-line1" }
        )

        uiState.cells[MulCell.P1TenThousands]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p1TenThousandsRef) {
                        baseline.linkTo(p1TensRef.baseline)
                        end.linkTo(p1ThousandsRef.start)
                    }
            )
        }

        uiState.cells[MulCell.P1Thousands]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p1ThousandsRef) {
                        baseline.linkTo(p1TensRef.baseline)
                        end.linkTo(p1HundredsRef.start)
                    }
            )
        }

        uiState.cells[MulCell.CarrySumThousands]?.let { c ->
            MulAuxNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = 8.dp)
                    .constrainAs(carrySumThousandsRef) {
                        start.linkTo(p1ThousandsRef.start)
                        bottom.linkTo(p1HundredsRef.top)
                    }
            )
        }

        uiState.cells[MulCell.P1Hundreds]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p1HundredsRef) {
                        baseline.linkTo(p1TensRef.baseline)
                        end.linkTo(p1TensRef.start)
                    }
            )
        }

        uiState.cells[MulCell.CarrySumHundreds]?.let { c ->
            MulAuxNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = 8.dp)
                    .constrainAs(carrySumHundredsRef) {
                        start.linkTo(p1HundredsRef.start)
                        bottom.linkTo(p1HundredsRef.top)
                    }
            )
        }

        uiState.cells[MulCell.P1Tens]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p1TensRef) {
                        top.linkTo(mlTensRef.bottom, margin = 40.dp)
                        start.linkTo(mcTensRef.start)
                    }
            )
        }

        uiState.cells[MulCell.P1Ones]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p1OnesRef) {
                        baseline.linkTo(p1TensRef.baseline)
                        start.linkTo(p1TensRef.end)
                    }
            )
        }

        uiState.cells[MulCell.P2TenThousands]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p2TenThousandsRef) {
                        baseline.linkTo(p2TensRef.baseline)
                        end.linkTo(p2ThousandsRef.start)
                    }
            )
        }

        uiState.cells[MulCell.CarrySumTenThousands]?.let { c ->
            MulAuxNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = 8.dp)
                    .constrainAs(carrySumTenThousandsRef) {
                        start.linkTo(p2TenThousandsRef.start)
                        bottom.linkTo(p1HundredsRef.top)
                    }
            )
        }

        uiState.cells[MulCell.P2Thousands]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p2ThousandsRef) {
                        baseline.linkTo(p2TensRef.baseline)
                        end.linkTo(p2HundredsRef.start)
                    }
            )
        }

        uiState.cells[MulCell.P2Hundreds]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p2HundredsRef) {
                        baseline.linkTo(p2TensRef.baseline)
                        end.linkTo(p2TensRef.start)
                    }
            )
        }
        uiState.cells[MulCell.P2Tens]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .padding(horizontal = horizPadding)
                    .constrainAs(p2TensRef) {
                        top.linkTo(p1TensRef.bottom, margin = 10.dp)
                        start.linkTo(mcTensRef.start)
                    }
            )
        }

        if(uiState.cells.values.any { it.totalLineType == TotalLineType.Confirmed}) {
            Image(
                painter = painterResource(id = R.drawable.ic_horizontal_line_long),
                contentDescription = "total-line",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .constrainAs(totalLineRef) {
                        top.linkTo(timesRef.bottom, margin = 160.dp)
                        start.linkTo(timesRef.start, margin = (-20).dp)
                        width = Dimension.value(200.dp)
                        height = Dimension.value(4.dp)
                    }
                    .semantics { testTag = "total-line" }
            )
        }

        uiState.cells[MulCell.SumTenThousands]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .constrainAs(sumTenThousandsRef) {
                        baseline.linkTo(sumTensRef.baseline)
                        end.linkTo(sumThousandsRef.start)
                    }
            )
        }
        uiState.cells[MulCell.SumThousands]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .constrainAs(sumThousandsRef) {
                        baseline.linkTo(sumTensRef.baseline)
                        end.linkTo(sumHundredsRef.start)
                    }
            )
        }
        uiState.cells[MulCell.SumHundreds]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .constrainAs(sumHundredsRef) {
                        baseline.linkTo(sumTensRef.baseline)
                        end.linkTo(sumTensRef.start)
                    }
            )
        }
        uiState.cells[MulCell.SumTens]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .constrainAs(sumTensRef) {
                        top.linkTo(p2TensRef.bottom, margin = 25.dp)
                        start.linkTo(mcTensRef.start)
                    }
            )
        }
        uiState.cells[MulCell.SumOnes]?.let { c ->
            MulNumberText(
                cell = c,
                modifier = Modifier
                    .width(cellWidth)
                    .constrainAs(sumOnesRef) {
                        baseline.linkTo(sumTensRef.baseline)
                        start.linkTo(sumTensRef.end)
                    }
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewMultiplicationBoard2x2() {
    val allCells = listOf(
        MulCell.MultiplicandHundreds,
        MulCell.MultiplicandTens,
        MulCell.MultiplicandOnes,

        MulCell.MultiplierTens,
        MulCell.MultiplierOnes,

        MulCell.P1Thousands,
        MulCell.P1Hundreds,
        MulCell.P1Tens,
        MulCell.P1Ones,

        MulCell.P2TenThousands,
        MulCell.P2Thousands,
        MulCell.P2Hundreds,
        MulCell.P2Tens,

        MulCell.SumTenThousands,
        MulCell.SumThousands,
        MulCell.SumHundreds,
        MulCell.SumTens,
        MulCell.SumOnes,

        MulCell.CarryP1Tens,
        MulCell.CarryP1Hundreds,

        MulCell.CarrySumTenThousands,
        MulCell.CarrySumThousands,
        MulCell.CarrySumHundreds
    )

    val fakeUiState = MulUiState(
        cells = allCells.associateWith { name ->
            MulInputCell(cellName = name, value = "?")
        },
        pattern = MulPattern.TwoByTwo,
        feedback = null
    )

    val previewUiState = fakeUiState.copy(
        cells = fakeUiState.cells.toMutableMap().apply {
            this[MulCell.MultiplicandHundreds]  = MulInputCell(MulCell.MultiplicandHundreds,  value = "9")
            this[MulCell.MultiplicandTens]  = MulInputCell(MulCell.MultiplicandTens,  value = "4")
            this[MulCell.MultiplicandOnes]  = MulInputCell(MulCell.MultiplicandOnes,  value = "8")
            this[MulCell.MultiplierTens]    = MulInputCell(MulCell.MultiplierTens,    value = "3")
            this[MulCell.MultiplierOnes]    = MulInputCell(MulCell.MultiplierOnes,    value = "6")

            this[MulCell.P1TenThousands]  = MulInputCell(MulCell.P1TenThousands,  value = "1")
            this[MulCell.P1Thousands]  = MulInputCell(MulCell.P1Thousands,  value = "1")
            this[MulCell.P1Hundreds]      = MulInputCell(MulCell.P1Hundreds,      value = "2")
            this[MulCell.P1Tens]      = MulInputCell(MulCell.P1Tens,      value = "2")
            this[MulCell.P1Ones]      = MulInputCell(MulCell.P1Ones,      value = "8")

            this[MulCell.P2TenThousands]  = MulInputCell(MulCell.P2TenThousands,  value = "9")
            this[MulCell.P2Thousands]  = MulInputCell(MulCell.P2Thousands,  value = "1")
            this[MulCell.P2Hundreds]  = MulInputCell(MulCell.P2Hundreds,  value = "1")
            this[MulCell.P2Tens]      = MulInputCell(MulCell.P2Tens,      value = "4")

            this[MulCell.SumTenThousands]    = MulInputCell(MulCell.SumTenThousands,    value = "9")
            this[MulCell.SumThousands]    = MulInputCell(MulCell.SumThousands,    value = "1")
            this[MulCell.SumHundreds]        = MulInputCell(MulCell.SumHundreds,        value = "7")
            this[MulCell.SumTens]        = MulInputCell(MulCell.SumTens,        value = "8")
            this[MulCell.SumOnes]        = MulInputCell(MulCell.SumOnes,        value = "8")

            this[MulCell.CarryP1Hundreds]        = MulInputCell(MulCell.CarryP1Hundreds,        value = "8")
            this[MulCell.CarryP1Tens]        = MulInputCell(MulCell.CarryP1Tens,        value = "8")
            this[MulCell.CarrySumTenThousands]        = MulInputCell(MulCell.CarrySumTenThousands,        value = "8")
            this[MulCell.CarrySumThousands]        = MulInputCell(MulCell.CarrySumThousands,        value = "8")
            this[MulCell.CarrySumHundreds]        = MulInputCell(MulCell.CarrySumHundreds,        value = "8")
        }
    )

    MultiplicationBoard(
        uiState = previewUiState
    )
}