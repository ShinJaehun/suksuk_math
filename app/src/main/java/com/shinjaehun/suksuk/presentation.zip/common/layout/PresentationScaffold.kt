package com.shinjaehun.suksuk.presentation.common.layout

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

//@Composable
//fun PresentationScaffold(
//    isLandscape: Boolean,
//    board: @Composable BoxScope.() -> Unit,
//    panel: @Composable BoxScope.() -> Unit,
//    // landscape tuning(세 화면에서 같은 값 사용)
//    designWidth: Dp = 360.dp,
//    designHeight: Dp = 560.dp,
//    minScale: Float = 0.45f,
////    boardWeight: Float = 1.2f,
////    panelWeight: Float = 1.5f,
//    boardWeight: Float = 3f,
//    panelWeight: Float = 1f,
//
////    contentWidthFraction: Float = 0.90f,
////    maxContentWidth: Dp = 1400.dp,
//
//    contentWidthFraction: Float = 0.96f,  // ← 0.90 → 0.96 (~+6.6%)
//    maxContentWidth: Dp = 1800.dp,        // ← 1400 → 1800 (혹은 null)
//
//    outerPadding: Dp = 16.dp,
//    innerGutter: Dp = 12.dp,
//) {
//    if (isLandscape) {
//        DualPaneBoardScaffold(
//            designWidth = designWidth,
//            designHeight = designHeight,
//            minScale = minScale,
//            boardWeight = boardWeight,
//            panelWeight = panelWeight,
//            contentWidthFraction = contentWidthFraction,
//            maxContentWidth = maxContentWidth,
//            outerPadding = outerPadding,
//            innerGutter = innerGutter,
//            board = { Box(Modifier.align(Alignment.TopCenter).fillMaxWidth()) { board() } },
//            panel = { Box(Modifier.fillMaxSize()) { panel() } }
//        )
//    } else {
//        Box(Modifier.fillMaxSize()) {
//            Box(Modifier.align(Alignment.TopCenter).fillMaxWidth()) { board() }
//            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) { panel() }
//        }
//    }
//}

@Composable
fun PresentationScaffold(
    isLandscape: Boolean,
    board: @Composable BoxScope.() -> Unit,
    panel: @Composable BoxScope.() -> Unit,
    designWidth: Dp = UiTokens.DesignBoardW,
    designHeight: Dp = UiTokens.DesignBoardH,
    minScale: Float = UiTokens.MinScale,
    boardWeight: Float = 2f,   // 좌/우 비율
    panelWeight: Float = 1f
) {
    if (isLandscape) {
        // ---- 가로: 좌 보드 / 우 패드 ----
        Row(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = UiTokens.Outer),
            horizontalArrangement = Arrangement.spacedBy(UiTokens.Gutter),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .weight(boardWeight)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                ScaledBoardBox(designWidth, designHeight, minScale) { board() }
            }
            Box(
                Modifier
                    .weight(panelWeight)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                // 패드 폭은 “가용폭 내”에서 스스로 정해지게(내부에서 계산)
                Box(Modifier.fillMaxWidth()) { panel() }
            }
        }
    } else {
        // ---- 세로: 위 보드 / 아래 패드 ----
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = UiTokens.Outer),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                ScaledBoardBox(designWidth, designHeight, minScale) { board() }
            }

            Spacer(Modifier.height(UiTokens.Gutter))

            // 패드: 화면 폭의 70% 정도에서 자동 배치(과대/과소 방지)
            Box(
                Modifier
                    .fillMaxWidth(0.7f)
                    .wrapContentHeight(),
                contentAlignment = Alignment.Center
            ) {
                panel()
            }

            Spacer(Modifier.height(UiTokens.PanelBottom))
        }
    }
}